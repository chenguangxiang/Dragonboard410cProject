package com.thundersoft.smartlight.Ui;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import com.thundersoft.smartlight.Code.Config;
import com.thundersoft.smartlight.Code.DialogByself;
import com.thundersoft.smartlight.Code.StringUtil;
import com.thundersoft.smartlight.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;
import java.util.zip.Inflater;

public class MainActivity extends Activity implements View.OnClickListener {
    private TextView timeopen, timeclose, red, red_light, green, green_light, blue, blue_light, allkind, handle_close, handle_open;
    private TimePicker startPicker, endPicker;
    private int start_hour, end_hour, start_minute, end_minute;
    private SeekBar seekBar;
    private boolean islight;
    private View dia_view;
    private String address;
    private String getreserve_code;
    private int getcolor_value;
    private static final int PORT = 3000;
    private static final int UdpPort = 4399;
    private static final int mili = 1000 * 60 * 60 * 24;
    public ServerSocket serverSocket;
    private BufferedReader input;
    private Handler handler;
    private int time = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        initview();
        Timepick();
        iniSeekbar();
        dia_view = getLayoutInflater().inflate(R.layout.dialog_byself, null, false);
        acceptUDP udp = new acceptUDP();
        udp.start();
        address = getLocAddress();
        handler = new Handler();
        RecevieSocket recevieSocket = new RecevieSocket();
        recevieSocket.start();
    }


    private void iniSeekbar() {
        seekBar = findViewById(R.id.brightness);
        if (!islight) {
            seekBar.setEnabled(false);
        }

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Config.WriteData(Config.brightness, "" + i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void Timepick() {
        startPicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                start_hour = i;
                start_minute = i1;
            }
        });

        endPicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                end_hour = i;
                end_minute = i1;
            }
        });
    }

    private void initview() {
        timeopen = findViewById(R.id.light);
        timeclose = findViewById(R.id.shutdown);
        red = findViewById(R.id.red);
        green = findViewById(R.id.green);
        blue = findViewById(R.id.blue);
        allkind = findViewById(R.id.white);
        startPicker = findViewById(R.id.reserve_open);
        endPicker = findViewById(R.id.reserve_close);
        handle_close = findViewById(R.id.handle_close);
        red_light = findViewById(R.id.red_light);
        green_light = findViewById(R.id.green_light);
        blue_light = findViewById(R.id.blue_light);
        handle_open = findViewById(R.id.handle_open);
        startPicker.setIs24HourView(true);
        endPicker.setIs24HourView(true);

        handle_open.setOnClickListener(this);
        handle_close.setOnClickListener(this);
        timeopen.setOnClickListener(this);
        timeclose.setOnClickListener(this);
        red.setOnClickListener(this);
        red_light.setOnClickListener(this);
        green_light.setOnClickListener(this);
        green.setOnClickListener(this);
        blue_light.setOnClickListener(this);
        blue.setOnClickListener(this);
        allkind.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.light:
                final DialogByself dialogByself = new DialogByself(this);

                dialogByself.setonConformClickListern(new DialogByself.Conform() {
                    @Override
                    public void getdata(String reserve_code, final int value) {
                        getreserve_code = reserve_code;
                        getcolor_value = value;
                        dialogByself.dismiss();
                        Log.e("key", getreserve_code + "yyyyyyyyyy" + getcolor_value);
                        AlarmManager alarmService = (AlarmManager) getSystemService(ALARM_SERVICE);
                        Calendar c = Calendar.getInstance();
                        final long systemTime = System.currentTimeMillis();
                        c.setTimeInMillis(System.currentTimeMillis());
                        c.setTimeZone(TimeZone.getTimeZone("GMT+8"));
                        c.set(Calendar.HOUR_OF_DAY, start_hour);
                        c.set(Calendar.MINUTE, start_minute);
                        c.set(Calendar.SECOND, 0);
                        c.set(Calendar.MILLISECOND, 0);
                        final long selectTime = c.getTimeInMillis();

                        Timer timer = new Timer();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                Config.WriteData(Config.color, getreserve_code);
                                Config.WriteData(Config.brightness, String.valueOf(value));

                            }
                        }, selectTime - systemTime, (1000 * 60 * 60 * 24));


                    }
                });
                dialogByself.setonCancleClickListern(new DialogByself.Cancle() {
                    @Override
                    public void dismissdialog(boolean ture) {
                        dialogByself.dismiss();
                    }
                });
                dialogByself.show();
                break;
            case R.id.shutdown:
                Log.i("close", "close");
                long current = System.currentTimeMillis();
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(System.currentTimeMillis());
                c.setTimeZone(TimeZone.getTimeZone("GMT+8"));
                c.set(Calendar.HOUR_OF_DAY, end_hour);
                c.set(Calendar.MINUTE, end_minute);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                final long selectTime = c.getTimeInMillis();
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Config.WriteData(Config.color, "0");
                    }
                }, selectTime - current, (1000 * 60 * 60 * 24));
                break;
            case R.id.red:
                Config.WriteData(Config.color, "1");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.blue:
                Config.WriteData(Config.color, "2");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.green:
                Config.WriteData(Config.color, "3");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.red_light:
                Config.WriteData(Config.color, "4");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.blue_light:
                Config.WriteData(Config.color, "5");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.green_light:
                Config.WriteData(Config.color, "6");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.white:
                Config.WriteData(Config.color, "10");
                islight = true;
                seekBar.setEnabled(true);
                break;
            case R.id.handle_close:
                if (islight) {
                    Config.WriteData(Config.color, "0");
                    seekBar.setEnabled(false);
                }
                break;
            case R.id.handle_open:
                Config.WriteData(Config.color, "10");
                islight = true;
                seekBar.setEnabled(true);
                break;
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      /*  Log.e("Crash", serverSocket.isClosed() + "");*/
    }

    class RecevieSocket extends Thread {

        @Override
        public void run() {
            Socket socket = null;
            try {
                serverSocket = new ServerSocket(PORT);

            } catch (IOException e) {
                e.printStackTrace();
            }
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    socket = serverSocket.accept();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Communication communication = new Communication(socket);
                communication.start();
            }

        }
    }

    class Communication extends Thread {
        private Socket socket;
        private BufferedReader input;
        private  String code = null;
        public Communication(Socket socket) {
            this.socket = socket;
            try {

                this.input = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                Log.i("finderror", socket.isConnected() + "");

                try {
                    code = input.readLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (StringUtil.get(0, code, "@") != null) {
                    switch (StringUtil.get(0, code, "@")) {
                        case "close":
                            Config.WriteData(Config.color, "0");
                            break;
                        case "open":
                            Config.WriteData(Config.color, "10");
                            break;
                        case "red":

                            Config.WriteData(Config.color, "1");
                            break;
                        case "red_light":
                            Config.WriteData(Config.color, "4");
                            break;
                        case "green":
                            Config.WriteData(Config.color, "3");
                            break;
                        case "green_light":
                            Config.WriteData(Config.color, "6");
                            break;
                        case "blue":
                            Config.WriteData(Config.color, "2");
                            break;
                        case "blue_light":
                            Config.WriteData(Config.color, "5");
                            break;
                        case "white":
                            Config.WriteData(Config.color, "10");
                            break;
                        case "reserve_open":
                            Calendar calendar = Calendar.getInstance();
                            long sys= System.currentTimeMillis();
                            calendar.setTimeInMillis(sys);
                            calendar.set(Calendar.HOUR_OF_DAY,Integer.parseInt(StringUtil.get(3,code,"@")));
                            Log.i("close",StringUtil.get(3,code,"@"));
                            calendar.set(Calendar.MINUTE,Integer.parseInt(StringUtil.get(4,code,"@")));
                             Log.i("close",StringUtil.get(4,code,"@"));
                            Timer opentime =new Timer();
                             Log.i("close",(calendar.getTimeInMillis()-sys)+"");
                            opentime.schedule(new TimerTask() {
                                @Override
                                public void run() {

                                    Log.i("result",StringUtil.get(1,code,"@")+"********"+StringUtil.get(2,code,"@")+"@@@@@@"+code);
                                   Config.WriteData(Config.color,StringUtil.get(1,code,"@"));
                                   Config.WriteData(Config.brightness,StringUtil.get(2,code,"@"));
                                }
                            },calendar.getTimeInMillis()-sys,(1000 * 60 * 60 * 24));

                            break;
                        case "reserve_close":
                            Calendar ca = Calendar.getInstance();
                            long system= System.currentTimeMillis();
                            ca.setTimeInMillis(system);
                            ca.set(Calendar.HOUR_OF_DAY,Integer.parseInt(StringUtil.get(1,code,"@")));
                            ca.set(Calendar.MINUTE,Integer.parseInt(StringUtil.get(2,code,"@")));
                            Timer close =new Timer();
                            close.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                  Config.WriteData(Config.color, "0");
                                }
                            },ca.getTimeInMillis()-system, (1000 * 60 * 60 * 24));
                            break;

                        case "brightness":
                            Config.WriteData(Config.brightness, Integer.parseInt(StringUtil.get(1, code, "@")) * 10 + "");
                            break;
                    }
                }
            }
        }

    }


    public class acceptUDP extends Thread {

        public DatagramSocket socket;

        @Override
        public void run() {
            try {

                socket = new DatagramSocket(UdpPort);
                Log.i("WifiController", "***");
                byte[] buffer = new byte[2048];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                Log.i("WifiController", "***");
                while (true) {
                    Log.i("WifiController", "%***%");
                    socket.receive(packet);
                    String re = new String(packet.getData(), 0, packet.getLength());
                    Log.i("WifiController", "&***&" + re);
                    if (re.equalsIgnoreCase("IP")) {


                        String back = Build.MODEL + "&" + address;
                        Log.i("WifiController", back);
                        DatagramPacket datagramPacket = new DatagramPacket(back.getBytes(), back.length(), packet.getSocketAddress());
                        socket.send(datagramPacket);
                        Log.i("WifiController", "" + packet.getSocketAddress());
                    }
                }
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (socket != null) {
                    socket.isClosed();
                }
            }


        }


    }

    public String getLocAddress() {

        String ipaddress = "";
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            // 遍历所用的网络接口
            while (en.hasMoreElements()) {
                NetworkInterface networks = en.nextElement();
                // 得到每一个网络接口绑定的所有ip
                Enumeration<InetAddress> address = networks.getInetAddresses();
                // 遍历每一个接口绑定的所有ip
                while (address.hasMoreElements()) {
                    InetAddress ip = address.nextElement();
                    if (!ip.isLoopbackAddress()
                            && !ip.isLinkLocalAddress()) {
                        ipaddress = ip.getHostAddress();
                    }
                }
            }

        } catch (SocketException e) {
            Log.e("ERROR", "获取本地ip地址失败");
            e.printStackTrace();
        }
        Log.e("ERROR", ipaddress);
        return ipaddress;

    }


}
