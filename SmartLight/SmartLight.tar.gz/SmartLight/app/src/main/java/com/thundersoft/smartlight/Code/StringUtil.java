package com.thundersoft.smartlight.Code;

/**
 * Created by root on 17-8-14.
 */

public class StringUtil {

    public  static String get(int index,String tem,String split){
        if (tem!=null){
            String a[] = tem.split(split);
            return a[index];
        }
        return null;
    }


}
