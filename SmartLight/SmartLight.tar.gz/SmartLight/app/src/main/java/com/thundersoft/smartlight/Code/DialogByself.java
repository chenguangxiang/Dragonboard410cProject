package com.thundersoft.smartlight.Code;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;

import com.thundersoft.smartlight.R;


public class DialogByself extends Dialog {


    public Conform conformListern;
    public Cancle cancelListern;
    public RadioGroup radioGroup;
    public SeekBar seekBar;
    public Button cancle, conform;
    public String reserve_code;
    private int light_value;

    public DialogByself(@NonNull Context context) {
        super(context);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_byself);
        setCanceledOnTouchOutside(false);
        initview();
        initdata();
        initEvent();
    }

    private void initEvent() {
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cancelListern!=null){
                    cancelListern.dismissdialog(true);
                }
            }
        });

        conform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (conformListern!=null){
                    conformListern.getdata(reserve_code,light_value);
                }
            }
        });

    }

    private void initdata() {
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup,  int i) {
                switch (i) {
                    case R.id.dia_red:
                        reserve_code = "1";
                        break;
                    case R.id.dia_red_light:
                        reserve_code = "4";
                        break;
                    case R.id.dia_blue:
                        reserve_code = "2";

                        break;
                    case R.id.dia_blue_light:
                        reserve_code = "5";
                        break;
                    case R.id.dia_green:
                        reserve_code = "3";
                        break;
                    case R.id.dia_green_light:
                        reserve_code = "6";
                        break;
                    case R.id.dia_white:
                        reserve_code = "10";
                        break;
                }
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                light_value = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void initview() {

        radioGroup = findViewById(R.id.dia_radio);
        seekBar = findViewById(R.id.dia_brightness);
        cancle = findViewById(R.id.cancle);
        conform = findViewById(R.id.comform);
    }

    public interface Conform {
        public void getdata(String reserve_code, int value);
    }

    public interface Cancle {
        public void dismissdialog(boolean ture);

    }

    public void setonConformClickListern(Conform conformListern){
           this.conformListern =conformListern;
    }

    public void setonCancleClickListern(Cancle cancelListern){
        this.cancelListern=cancelListern;
    }


}
