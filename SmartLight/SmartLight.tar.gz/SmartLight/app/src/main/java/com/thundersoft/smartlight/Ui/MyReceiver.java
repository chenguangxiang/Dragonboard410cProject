package com.thundersoft.smartlight.Ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.thundersoft.smartlight.Code.Config;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equalsIgnoreCase("open")) {
                Log.e("Open","9999999999");
                Config.WriteData(Config.color, intent.getStringExtra("getreserve_code"));
                Log.i("light",intent.getStringExtra("getcolor_value"));
                Config.WriteData(Config.brightness,intent.getStringExtra("getcolor_value"));
            } else {
                Log.e("Open","66666666666");
                Config.WriteData(Config.color, "0");
            }
    }


}
