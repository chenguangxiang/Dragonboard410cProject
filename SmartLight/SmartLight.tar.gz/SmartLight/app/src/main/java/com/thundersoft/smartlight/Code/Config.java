package com.thundersoft.smartlight.Code;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

/**
 * Created by root on 17-7-13.
 */

public class Config {

    public  static  final  String color="/sys/bus/i2c/devices/6-0045/led";
     public  static  final  String brightness="/sys/bus/i2c/devices/6-0045/bright";

    public static String getConfig(Context context, String FileName, String key) {
        Properties properties = new Properties();
        InputStream in = null;
        try {
            in = context.getAssets().open(FileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            properties.load(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String tem = (String) properties.get(key);
        try {
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tem;
    }
    /*
    * some problem
    * */
    public static void setConfig(Context context, String FileName, String key, String value) throws IOException {
        Properties properties = new Properties();
        InputStream in = null;
        in = context.getAssets().open(FileName);
        properties.load(in);
        properties.setProperty(key, value);
        FileOutputStream fileOutputStream = new FileOutputStream("file:///android_asset/"+ FileName);
        properties.store(fileOutputStream, null);
        fileOutputStream.flush();
        fileOutputStream.close();
        in.close();
    }

    public static void writenomer(String path,String key,String value){
        Properties properties = new Properties();
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
          properties.setProperty(key, value);
        try {
            properties.store(fileOutputStream,null);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fileOutputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void WriteData(String path, String content) {
        FileOutputStream fos = null;
        File file = new File(path);
        if (file.exists()) {
            try {
                fos = new FileOutputStream(file);
                Log.e("File", "FileWriter"+content);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte[] array = content.getBytes();
            try {
                fos.write(array);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                fos.flush();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    public static String Redata(String path) {
        String content = new String();
        String line = new String();
        InputStreamReader is = null;
        File file = new File(path);
        if (file.exists()) {
            try {
                is = new InputStreamReader(new FileInputStream(file));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            BufferedReader bufferedReader = new BufferedReader(is);
            try {
                while ((line = bufferedReader.readLine()) != null) {
                    content = content + line;

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return content;
    }

    public ArrayList<HashMap<String, String>> back(Context context, String path) {
        ArrayList<HashMap<String, String>> content = new ArrayList<>();
        Properties properties = new Properties();
        InputStream is = null;
        try {
            is = context.getAssets().open(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            properties.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Set<Object> code = properties.keySet();

        //TODO get the config of different TV
        return content;
    }

/*
    public static void writedata(String path, String content) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        File file = null;
        try {
            file = new File(path);
            if (file.exists()) {
                Log.e("File", "isExists" + file.getAbsolutePath());
                fw = new FileWriter(file, true);
                Log.e("File", "FileWriter");
                if (file.canWrite()) {
                    bw = new BufferedWriter(fw);
                    bw.write(content);
                    bw.flush();
                    fw.flush();
                    bw.close();
                    fw.close();

                } else {

                    fw.flush();
                    fw.close();

                }

            }

        } catch (IOException e) {
            Log.e("IOException", "" + e);
            e.printStackTrace();


        }


    }*/
}