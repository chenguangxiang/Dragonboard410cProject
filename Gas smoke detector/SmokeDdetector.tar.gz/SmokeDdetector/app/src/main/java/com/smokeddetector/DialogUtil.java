package com.smokeddetector;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

/**
 * Created by root on 17-7-20.
 */

public class DialogUtil {


    public static AlertDialog.Builder build(Context context){
        final AlertDialog.Builder builder= new AlertDialog.Builder(context);
        builder.setTitle("Warning");
        builder.setMessage("温度太高湿度太低　注意防火！！！！！！！！！！");
        builder.setNegativeButton("conform", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                builder.create().cancel();
            }
        });
        return builder;
    }

}
