package com.smokeddetector;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.IntDef;

public class PlayWarning extends Service {
    private MediaPlayer mediaPlayer;
    private boolean isStop = true;

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        switch (intent.getIntExtra("type", -1)){
            case MainActivity.PLAT_MUSIC:
                if (isStop) {
                    mediaPlayer.reset();
                    mediaPlayer = MediaPlayer.create(this, R.raw.waring);
                    mediaPlayer.start();
                    mediaPlayer.setLooping(true);
                    isStop = false;
                } else if (!isStop && mediaPlayer.isPlaying() && mediaPlayer != null) {
                    mediaPlayer.start();
                  }
                break;

            case MainActivity.STOP_MUSIC:
                if (mediaPlayer != null) {
                    //停止之后要开始播放音乐
                    mediaPlayer.stop();
                    isStop = true;
                }

                break;

        }

        return START_NOT_STICKY;

    }
}
