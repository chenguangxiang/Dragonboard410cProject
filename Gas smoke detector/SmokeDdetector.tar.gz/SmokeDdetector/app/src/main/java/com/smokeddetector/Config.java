package com.smokeddetector;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

/**
 * Created by root on 17-7-13.
 */

public class Config {

    public static String temperature = "/dev/dht11";

    public static String smoke = "/sys/bus/platform/drivers/MQ-2/mq-2.66/value";

    public static String light = "/sys/bus/platform/drivers/red/rgb_red.64/value";


    public static void WriteData(String path, String content) {
        FileOutputStream fos = null;
        File file = new File(path);
        if (file.exists()) {
            try {
                Log.i("smoke",path);
                fos = new FileOutputStream(file);
                Log.e("File", "FileWriter");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte[] array = content.getBytes();
            try {
                fos.write(array);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                fos.flush();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    public static String readother(String path) {
        String content = "";
        File file= new File(path);
        if (file.exists()){
            FileInputStream fis= null;
            try {
                fis = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte tem[]= new byte[(int) file.length()+10];
            try {
                fis.read(tem);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                content=new String(tem,"UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            try {
                fis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return content;
    }

    public static String TemRedata(String path) {
        String content = "";
        byte a[] = new byte[10];
        File file = new File(path);
        if (file.exists()) {
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                fis.read(a, 0, 3);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.e("value ++++++++++", a.length+"");
            int tem0= a[0]  & 0xFF;
            int tem1= a[1]  & 0xFF;
            int tem2= a[2]  & 0xFF;
            int tem3= a[3]  & 0xFF;
            content=tem0+"."+tem1+"/"+tem2+"."+tem3;
            try {
                fis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return content;
    }



}