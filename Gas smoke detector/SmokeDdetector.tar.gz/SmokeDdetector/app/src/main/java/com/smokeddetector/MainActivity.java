package com.smokeddetector;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

import static android.content.ContentValues.TAG;

public class MainActivity extends Activity {

    private TextView platform_temperature, dampness;
    private Button button, reset;
    private Timer timer;
    public static final int PLAT_MUSIC = 1;
    public static final int STOP_MUSIC = 3;
    private static boolean paly_status;
    private static boolean timer_status;//0 cancle ;1 actived
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Log.e("msg", msg.arg1 + "");
            String value = (String) msg.getData().get("value");
            boolean flag = (boolean) msg.getData().get("flag");
            String a[] = value.split("/");
            platform_temperature.setText(a[1] + "℃");
            dampness.setText(a[0] + "%RH");
            if (flag) {
                playmusic(PLAT_MUSIC);
                Config.WriteData(Config.light,"0");
                paly_status=true;
                timer.cancel();
                timer.purge();
            }
            if (Double.valueOf(a[1]) > 45.0 && Double.valueOf(a[0]) < 40.0) {
                DialogUtil.build(MainActivity.this).create().show();
            }

        }
    };

    private void playmusic(int type) {
        Intent intent = new Intent(MainActivity.this, PlayWarning.class);
        intent.putExtra("type", type);
        startService(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        initview();
        Log.e("Start", "timer");
        readdate();
        Log.e("End", "timer");
        timer_status = true;
        reset.setEnabled(false);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playmusic(STOP_MUSIC);
                Config.WriteData(Config.light,"1");
                paly_status=false;
                reset.setEnabled(true);
            }
        });


        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readdate();
                reset.setEnabled(false);
            }
        });
    }



    private void readdate() {
        timer = new Timer();
        Log.e("OK1","OK");
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Log.e("OK2","OK");
                Message message = new Message();
                String value = Config.TemRedata(Config.temperature);
                boolean flag = Config.readother(Config.smoke).startsWith("0");
                Log.e("value", value);
                Log.e("flag", flag + "");
                Bundle bundle = new Bundle();
                bundle.putString("value", value);
                bundle.putBoolean("flag", flag);
                message.setData(bundle);
                handler.sendMessage(message);

            }
        }, 1000, 1000);

    }


    private void initview() {
        platform_temperature = findViewById(R.id.value_temperature);
        dampness = findViewById(R.id.value_dampness);
        button = findViewById(R.id.stop);
        reset = findViewById(R.id.reser);
        button.setFocusable(false);
        reset.setFocusable(false);
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
         Log.e("flag1",   ""+keyCode);
        if (keyCode==event.KEYCODE_ENTER) {
          Log.e("flag2",   ""+keyCode);
            Config.WriteData(Config.light,"1");
            if (paly_status){
                 Log.e("flag3",   ""+keyCode);
                playmusic(STOP_MUSIC);
                reset.setEnabled(true);
                return true;
            }

        }
        return false;
    }
}
