package com.thundersoft.recognizeface.ui;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.IdentityListener;
import com.iflytek.cloud.IdentityResult;
import com.iflytek.cloud.SpeechError;
import com.thundersoft.recognizeface.Config;
import com.thundersoft.recognizeface.FaceUtil;
import com.thundersoft.recognizeface.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.Permission;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {

    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    private TextureView textureView;
    private String TAG = "takepic";
    private String[] all = null;
    private CameraCharacteristics characteritics = null;
    private CameraDevice.StateCallback openCamera = null;
    private HandlerThread handlerThread;
    private Handler mhander, Mainhandle;
    private CameraCaptureSession.StateCallback creatsession = null;
    private CaptureRequest.Builder requestbuild = null;
    private CameraCaptureSession.CaptureCallback getback = null;
    private CameraDevice device;
    private ImageReader mImageReader;
    private CameraCaptureSession msession;
    private Button capture;
    private String path = "/sdcard/pic/" + "tem.jpg";
    private FaceUtil faceUtil;
    private boolean reg_resul = true;

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            // Toast.makeText(MainActivity.this,msg.getData().getString("msg"),Toast.LENGTH_SHORT);
            capture.setText(msg.getData().getString("msg"));
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        capture = findViewById(R.id.capture);
        handlerThread = new HandlerThread("Camera2");
        handlerThread.start();
        mhander = new Handler(handlerThread.getLooper());
        Mainhandle = new Handler(getMainLooper());
        intCamera();
        textureView = findViewById(R.id.preview);
        textureView.setSurfaceTextureListener(listener);
        faceUtil = FaceUtil.getinstances();
        faceUtil.init(this);

       /* Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.i(TAG, "~~~~~~~~~~~~~~~~~~~~~~~~~" + Config.Redata(Config.key));
                if (Integer.parseInt(Config.Redata(Config.key)) < 400) {
                    Log.i(TAG, "~~~~~~~~~~~~~~~~~~~~~~~~~" + Config.Redata(Config.key));
                    if (reg_resul) {
                        //faceUtil.register(Config.getBytes(FaceUtil.register_path), "enroll", mEnrollListener);
                        sendmessage("Register:Successs");
                        // Toast.makeText(MainActivity.this,"Register:Successs",Toast.LENGTH_SHORT);
                        reg_resul = false;
                    } else {
                        //takePicture();
                        //faceUtil.register(Config.getBytes(path), "verify", mVerifyListener);
                        sendmessage("verify:Successs");
                        // Toast.makeText(MainActivity.this,"verify:Successs",Toast.LENGTH_SHORT);
                    }
                }
            }
        }, 1000, 3 * 1000);*/
    }

    private void sendmessage(String s) {
        Message message = new Message();
        Bundle bundle = new Bundle();
        bundle.putString("msg", s);
        message.setData(bundle);
        handler.sendMessage(message);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("TAG", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("TAG", "onPause");
    }


    private TextureView.SurfaceTextureListener listener = new TextureView.SurfaceTextureListener() {

        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            mImageReader = ImageReader.newInstance(1080, 1920, ImageFormat.JPEG, 1);
            mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = reader.acquireNextImage();
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    saveImg(bytes);
                }
            }, Mainhandle);

            CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
            try {
                all = manager.getCameraIdList();
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
            try {
                characteritics = manager.getCameraCharacteristics(all[0]);
                Log.d("Camera", all[0]);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
            if (openCamera != null) {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                try {
                    manager.openCamera(all[0], openCamera, Mainhandle);
                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {


        }
    };


    private void intCamera() {
        openCamera = new CameraDevice.StateCallback() {
            @Override
            public void onOpened(@NonNull CameraDevice camera) {
                device = camera;
                if (camera != null) {
                    try {
                        startprew(camera);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onDisconnected(@NonNull CameraDevice camera) {
                camera.close();
                camera = null;
            }

            @Override
            public void onError(@NonNull CameraDevice camera, int error) {

            }
        };

        creatsession = new CameraCaptureSession.StateCallback() {
            @Override
            public void onConfigured(@NonNull CameraCaptureSession session) {
                requestbuild.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
                try {
                    msession = session;
                    msession.setRepeatingRequest(requestbuild.build(), getback, mhander);

                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onConfigureFailed(@NonNull CameraCaptureSession session) {

            }
        };


        getback = new CameraCaptureSession.CaptureCallback() {
            @Override
            public void onCaptureCompleted(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
                super.onCaptureCompleted(session, request, result);
            }

            @Override
            public void onCaptureFailed(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull CaptureFailure failure) {
                super.onCaptureFailed(session, request, failure);
            }
        };
    }

    private void startprew(CameraDevice device) throws CameraAccessException {
        SurfaceTexture surface = textureView.getSurfaceTexture();
        surface.setDefaultBufferSize(textureView.getWidth(), textureView.getHeight());
        Surface surfaceview = new Surface(surface);
        requestbuild = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
        requestbuild.addTarget(surfaceview);
        device.createCaptureSession(Arrays.asList(surfaceview, mImageReader.getSurface()), creatsession, mhander);
    }

    private void takePicture() {
        if (device == null) return;
        // 创建拍照需要的CaptureRequest.Builder
        final CaptureRequest.Builder captureRequestBuilder;
        try {
            captureRequestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureRequestBuilder.addTarget(mImageReader.getSurface());
            captureRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            captureRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
            int rotation = getWindowManager().getDefaultDisplay().getRotation();
            captureRequestBuilder.set(CaptureRequest.JPEG_ORIENTATION, ORIENTATIONS.get(rotation));
            CaptureRequest mCaptureRequest = captureRequestBuilder.build();
            msession.capture(mCaptureRequest, getback, mhander);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void saveImg(byte[] a) {
        if (a != null) {
            File file = new File(path);
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                fos.write(a);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                fos.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private IdentityListener mEnrollListener = new IdentityListener() {

        @Override
        public void onResult(IdentityResult result, boolean islast) {
            Log.d("TAG", result.getResultString());
            try {
                JSONObject object = new JSONObject(result.getResultString());
                int ret = object.getInt("ret");

                if (ErrorCode.SUCCESS == ret) {
                    Log.d("TAG", "注册成功");
                    reg_resul = true;
                } else {
                    Log.d("TAG", new SpeechError(ret).getPlainDescription(true));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {

        }

        @Override
        public void onError(SpeechError error) {
            Log.d("TAG", error.getPlainDescription(true));
        }

    };


    private IdentityListener mVerifyListener = new IdentityListener() {

        @Override
        public void onResult(IdentityResult result, boolean islast) {
            Log.d("TAG", result.getResultString());
            try {
                JSONObject object = new JSONObject(result.getResultString());
                Log.d("TAG", "object is: " + object.toString());
                String decision = object.getString("decision");

                if ("accepted".equalsIgnoreCase(decision)) {
                    Log.d("TAG", "通过验证");
                    textureView.setVisibility(View.INVISIBLE);
                } else {
                    Log.d("TAG", "验证失败");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {

        }

        @Override
        public void onError(SpeechError error) {

            Log.d("TAG", error.getPlainDescription(true));
        }

    };
}
