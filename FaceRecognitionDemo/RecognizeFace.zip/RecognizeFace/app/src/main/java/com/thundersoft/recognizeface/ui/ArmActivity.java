package com.thundersoft.recognizeface.ui;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;

import com.thundersoft.recognizeface.Config;
import com.thundersoft.recognizeface.R;


public class ArmActivity extends Activity {

    private SeekBar one, two, three, four, five, six, seven;
    private boolean isfirst = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arm);
        initview();
        one.setProgress(50);
        two.setProgress(50);
        three.setProgress(50);
        four.setProgress(50);
        five.setProgress(50);
        six.setProgress(50);
        //seven.setProgress(50);
        initevent();
    }

    private void initevent() {
        one.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(1, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        two.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(2, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        three.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(3, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        four.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(4, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        five.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(5, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        six.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!isfirst) {
                    Config.writeALL(0);
                    isfirst = true;
                }
                Config.writeArm(6, 500000 + 22000 * progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void initview() {
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Config.writeALL(1);
    }
}
