package com.thundersoft.recognizeface.ui;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.thundersoft.recognizeface.Api;
import com.thundersoft.recognizeface.Config;
import com.thundersoft.recognizeface.R;
import com.wilddog.client.DataSnapshot;
import com.wilddog.client.SyncError;
import com.wilddog.client.SyncReference;
import com.wilddog.client.ValueEventListener;
import com.wilddog.client.WilddogSync;
import com.wilddog.wilddogcore.WilddogApp;
import com.wilddog.wilddogcore.WilddogOptions;

import java.util.Timer;
import java.util.TimerTask;

import io.agora.rtc.Constants;
import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.video.VideoCanvas;


public class CarActivity extends Activity implements View.OnClickListener {

    private TextView forward, back, left, right, close;
    private SeekBar speed;
    private final static String TAG = "SmartCar";
    private int status = 0;
    private Timer timer;
    private String APP_ID = "wd3019382788vsndgl";
    private RtcEngine mRtcEngine;
    private int i = 0;
    private boolean isfirst = true;
    private int CurrentModel;
    private boolean isinit = false;

    private final IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() { // Tutorial Step 1
        @Override
        public void onFirstRemoteVideoDecoded(final int uid, int width, int height, int elapsed) { // Tutorial Step 5
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setupRemoteVideo(uid);
                }
            });
        }

        @Override
        public void onUserOffline(int uid, int reason) { // Tutorial Step 7
           /* runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onRemoteUserLeft();
                }
            });*/
        }

        @Override
        public void onUserMuteVideo(final int uid, final boolean muted) { // Tutorial Step 10
          /*  runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onRemoteUserVideoMuted(uid, muted);
                }
            });*/
        }
    };

    public Handler listernCode = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.arg1) {
                case 0:
                    Log.i("Message", CurrentModel + "");
                    if (CurrentModel == 1) {
                        Api.forward((long) (Integer.parseInt(msg.getData().getString("finction")) * 1.85 * 100000 + 1500000));
                        ;
                    } else if (CurrentModel == 2) {
                        Api.back((long) (Integer.parseInt(msg.getData().getString("finction")) * 1.85 * 100000 + 1500000));
                    } else if (CurrentModel == 3) {
                        Api.left((long) (Integer.parseInt(msg.getData().getString("finction")) * 1.85 * 100000 + 1500000));
                    } else if (CurrentModel == 4) {
                        Api.right((long) (Integer.parseInt(msg.getData().getString("finction")) * 1.85 * 100000 + 1500000));
                    } else {
                        Toast.makeText(CarActivity.this, "请先选择模式", Toast.LENGTH_SHORT);
                    }
                    break;
                case 1:
                    CurrentModel = 1;
                    Api.forward(7500000);
                    break;
                case 2:
                    CurrentModel = 2;
                    Api.back(7500000);
                    break;
                case 3:
                    CurrentModel = 3;
                    Api.left(7500000);
                    break;
                case 4:
                    CurrentModel = 4;
                    Api.right(7500000);
                    break;
                case 5:
                    Api.stop();
                    break;
            }
        }
    };


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car);
        //WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        //requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, 0);
        initview();
        /*timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                String a[] = Config.location().split("@");
                if (Integer.parseInt(a[0]) < 1000) {
                    if (Integer.parseInt(a[1]) < Integer.parseInt(a[2])) {
                        Api.right((long) (20 * 1.85 * 100000 + 1500000));
                    } else {
                        Api.left((long) (20 * 1.85 * 100000 + 1500000));
                    }
                }
            }
        }, 0, 200);*/
        initLisetren();

    }

    private void initLisetren() {
        WilddogOptions options = new WilddogOptions.Builder().setSyncUrl("https://" + APP_ID + ".wilddogio.com").build();
        WilddogApp.initializeApp(this, options);
        SyncReference ref = WilddogSync.getInstance().getReference().child("car");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String tem = dataSnapshot.child("finction").getValue().toString();
                switch (tem) {
                    case "Speed":
                        SendMess(0, dataSnapshot.child("code").getValue().toString());
                        break;
                    case "Forward":
                        SendMess(1, "Forward");
                        break;
                    case "Back":
                        SendMess(2, "Back");
                        break;
                    case "Left":
                        SendMess(3, "Left");
                        break;
                    case "Right":
                        SendMess(4, "Right");
                        break;
                    case "Close":
                        SendMess(5, "Close");
                        break;
                    case "one":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(1, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                    case "two":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(2, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                    case "three":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(3, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                    case "four":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(4, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                    case "five":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(5, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                    case "six":
                        if (!isinit) {
                            initarm();
                        }
                        Config.writeArm(6, 500000 + 22000 * Integer.parseInt(dataSnapshot.child("code").getValue().toString()));
                        break;
                }

            }

            @Override
            public void onCancelled(SyncError syncError) {

            }
        });
    }

    public void SendMess(int i, String re) {
        Message message = new Message();
        Bundle bundle = new Bundle();
        bundle.putString("finction", re);
        message.arg1 = i;
        message.setData(bundle);
        listernCode.sendMessage(message);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "resume");
        initAgoraEngineAndJoinChannel();
    }

    private void initview() {
        forward = findViewById(R.id.forward);
        forward.setOnClickListener(this);
        back = findViewById(R.id.back);
        back.setOnClickListener(this);
        left = findViewById(R.id.Left);
        left.setOnClickListener(this);
        right = findViewById(R.id.Right);
        right.setOnClickListener(this);
        speed = findViewById(R.id.speeds);
        close = findViewById(R.id.close);
        close.setOnClickListener(this);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                switch (status) {
                    case 1:
                        Api.back((long) (progress * 1.85 * 100000 + 1500000));
                        break;
                    case 2:
                        Api.forward((long) (progress * 1.85 * 100000 + 1500000));
                        break;
                    case 3:
                        Api.left((long) (progress * 1.85 * 100000 + 1500000));
                        break;
                    case 4:
                        Api.right((long) (progress * 1.85 * 100000 + 1500000));
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void initarm() {
        Config.writeArm(1, 500000 + 22000 * 50);
        Config.writeArm(2, 500000 + 22000 * 50);
        Config.writeArm(3, 500000 + 22000 * 50);
        Config.writeArm(4, 500000 + 22000 * 50);
        Config.writeArm(5, 500000 + 22000 * 50);
        Config.writeArm(6, 500000 + 22000 * 50);
        isinit = true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                Api.back(1500000);
                status = 1;
                break;
            case R.id.forward:
                Api.forward(1500000);
                status = 2;
                break;
            case R.id.Left:
                Api.left(1500000);
                status = 3;
                break;
            case R.id.Right:
                Api.right(1500000);
                status = 4;
                break;
            case R.id.close:
                Api.stop();
                status = 0;
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 0:
                if (permissions[0].equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        i = i + 1;
                    }
                }
                break;
            case 1:
                if (permissions[1].equals(Manifest.permission.RECORD_AUDIO)) {
                    if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                        i = i + 1;
                    }
                }
                break;
            case 2:
                if (permissions[2].equals(Manifest.permission.RECORD_AUDIO)) {
                    if (grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                        i = i + 1;
                    }
                }
                break;

        }

        Log.i(TAG, "onRequestPermissionsResult" + isfirst + "" + i);
    }

    private void initAgoraEngineAndJoinChannel() {
        initializeAgoraEngine();     // Tutorial Step 1
        setupVideoProfile();         // Tutorial Step 2
        setupLocalVideo();           // Tutorial Step 3
        joinChannel();               // Tutorial Step 4
    }

    private void setupRemoteVideo(int uid) {
        LinearLayout container = this.findViewById(R.id.local);
        SurfaceView surfaceView = RtcEngine.CreateRendererView(getBaseContext());
        container.addView(surfaceView);
        mRtcEngine.setupRemoteVideo(new VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_ADAPTIVE, uid));
    }

    private void initializeAgoraEngine() {
        try {
            mRtcEngine = RtcEngine.create(getBaseContext(), getString(R.string.agora_app_id), mRtcEventHandler);
        } catch (Exception e) {
            Log.e("tag", Log.getStackTraceString(e));
            throw new RuntimeException("NEED TO check rtc sdk init fatal error\n" + Log.getStackTraceString(e));
        }
    }

    private void setupVideoProfile() {
        mRtcEngine.enableVideo();
        mRtcEngine.setVideoProfile(Constants.VIDEO_PROFILE_360P, false);
    }

    private void joinChannel() {
        mRtcEngine.joinChannel(null, "demoChannel1", "Extra Optional Data", 0); // if you do not specify the uid, we will generate the uid for you
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        leaveChannel();
        RtcEngine.destroy();
        mRtcEngine = null;
    }

    private void leaveChannel() {
        mRtcEngine.leaveChannel();
    }

    private void setupLocalVideo() {
        LinearLayout local = findViewById(R.id.remote);
        SurfaceView surfaceView = RtcEngine.CreateRendererView(getBaseContext());
        local.addView(surfaceView);
        mRtcEngine.setupLocalVideo(new VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_ADAPTIVE, 0));
    }
}
