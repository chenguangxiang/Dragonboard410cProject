package com.thundersoft.recognizeface;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.FaceRequest;
import com.iflytek.cloud.IdentityListener;
import com.iflytek.cloud.IdentityResult;
import com.iflytek.cloud.IdentityVerifier;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by yangxu0703 on 17-11-10.
 */

public class FaceUtil {

    public String mAuthid = null;
    public static FaceUtil faceUtil;
    private IdentityVerifier mIdVerifier;
    public static String register_path = "/sdcard/pic/register/IMG_19700101_034007.jpg";

    public static FaceUtil getinstances() {
        if (faceUtil == null) {
            faceUtil = new FaceUtil();
        }
        return faceUtil;
    }

    public void init(Context context) {
        mIdVerifier = IdentityVerifier.createVerifier(context, new InitListener() {
            @Override
            public void onInit(int errorCode) {
                if (ErrorCode.SUCCESS == errorCode) {
                    Log.i("TAG", "引擎初始化成功");
                } else {
                    Log.i("TAG", "引擎初始化失败，错误码：" + errorCode);
                }
            }
        });
    }

    public void register(byte[] mImageData, String action,IdentityListener Listener ) {
        if (null != mImageData) {

            mIdVerifier.setParameter(SpeechConstant.PARAMS, null);
            mIdVerifier.setParameter(SpeechConstant.MFV_SCENES, "ifr");
            if (action.equals("enroll")) {
                mIdVerifier.setParameter(SpeechConstant.MFV_SST, "enroll");
                mIdVerifier.setParameter(SpeechConstant.AUTH_ID, mAuthid);
                mIdVerifier.startWorking(Listener);
            } else if (action.equals("verify")) {
                mIdVerifier.setParameter(SpeechConstant.MFV_SST, "verify");
                mIdVerifier.setParameter(SpeechConstant.MFV_VCM, "sin");
                mIdVerifier.setParameter(SpeechConstant.AUTH_ID, mAuthid);
                mIdVerifier.startWorking(Listener);
            } else {
                return;
            }
            StringBuffer params = new StringBuffer();
            mIdVerifier.writeData("ifr", params.toString(), mImageData, 0, mImageData.length);
            mIdVerifier.stopWrite("ifr");
        } else {
            Log.i("TAG", "请选择图片后再注册");
        }
    }


}
