package com.thundersoft.smartcar.UI;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.thundersoft.smartcar.R;
import com.thundersoft.smartcar.Util.Api;

public class MainActivity extends Activity implements View.OnClickListener {

    private TextView forward, back, left, right, close;
    private SeekBar speed;
    private final static String TAG = "SmartCar";
    private int status = 0;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        //this.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE},0);
        initview();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "resume");
    }

    private void initview() {
        forward = findViewById(R.id.Forward);
        forward.setOnClickListener(this);
        back = findViewById(R.id.back);
        back.setOnClickListener(this);
        left = findViewById(R.id.Left);
        left.setOnClickListener(this);
        right = findViewById(R.id.Right);
        right.setOnClickListener(this);
        speed = findViewById(R.id.speeds);
        close = findViewById(R.id.close);
        close.setOnClickListener(this);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                switch (status) {
                    case 1:
                        Api.back((long) (progress*1.85*100000+1500000));
                        break;
                    case 2:
                        Api.forward((long) (progress*1.85*100000+1500000));
                        break;
                    case 3:
                        Api.left((long) (progress*1.85*100000+1500000));
                        break;
                    case 4:
                        Api.right((long) (progress*1.85*100000+1500000));
                        break;
                        default:
                            break;
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                Api.back(1500000);
                status = 1;
                break;
            case R.id.Forward:
                Api.forward(1500000);
                status = 2;
                break;
            case R.id.Left:
                Api.left(1500000);
                status = 3;
                break;
            case R.id.Right:
                Api.right(1500000);
                status = 4;
                break;
            case R.id.close:
                Api.stop();
                status = 0;
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 0:
                if (permissions[0].equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    }
                }
                break;
        }
        Log.i(TAG, "onRequestPermissionsResult");
    }


}
