package com.thundersoft.smartcar.Util;

/**
 * Created by yangxu0703 on 17-11-16.
 */

public class Api {

    private static String leftback = "/sys/class/pwm/pwmchip1/pwm0/duty";
    private static String leftforward = "/sys/class/pwm/pwmchip1/pwm1/duty";
    private static String rightforward = "/sys/class/pwm/pwmchip1/pwm2/duty";
    private static String rightback = "/sys/class/pwm/pwmchip1/pwm3/duty";
    private static String voice = "/sys/devices/soc.0/sonar.*/value";
    private static String red_light = "/sys/devices/soc.0/ir-red.*/value";

    public static void forward(long speeed) {
        stop();
        Config.WriteData(leftforward, "" + speeed);
        Config.WriteData(rightforward, "" + speeed);
    }

    public static void back(long speeed) {
        stop();
        Config.WriteData(leftback, "" + speeed);
        Config.WriteData(rightback, "" + speeed);
    }

    public static void left(long speeed) {
        stop();
        Config.WriteData(leftforward, "" + 0);
        Config.WriteData(rightforward, "" + speeed);
    }

    public static void right(long speeed) {
        stop();
        Config.WriteData(leftforward, "" + speeed);
        Config.WriteData(rightforward, "" + 0);
    }

    public static void stop() {
        Config.WriteData(leftback, "" + 0);
        Config.WriteData(leftforward, "" + 0);
        Config.WriteData(rightforward, "" + 0);
        Config.WriteData(rightback, "" + 0);
    }

}
