package com.thundersoft.smartremotecontroller.smartremotecontroller.Ui;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.Config;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.DialogUtil;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.SharedPreferenceManage;
import com.thundersoft.smartremotecontroller.smartremotecontroller.R;

import java.io.IOException;
import java.util.ArrayList;


public class ControllerActivity extends Activity implements View.OnClickListener {

    private TextView zero, one, two, three, four, five, six, vol_de, vol_plus,
            seven, eight, nine, up, down, left, right, cancle, conform;
    private Spinner pick;
    private Button smart_learn;
    private int index;
    public static SharedPreferences LETV, KONKA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controller);
        initStore();
        initview();
        repuestpermission();

    }

    private void operationpick() {

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.item_spiner, SharedPreferenceManage.all);
        pick.setAdapter(arrayAdapter);
        pick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                index = i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

  /*  @NonNull
    public static ArrayList<String> getStrings(Context context) {
        ArrayList<String> array = new ArrayList<>();
        String[] allfile = new String[0];
        try {
            allfile = context.getAssets().list("");
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (String con_path : allfile) {
            if (con_path.endsWith("Config.properties"))
                array.add(con_path);
        }
        return array;
    }*/

    private void repuestpermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
    }

    private void initview() {
        vol_de = findViewById(R.id.vol_de);
        vol_plus = findViewById(R.id.vol_plus);
        cancle = findViewById(R.id.cancle);
        conform = findViewById(R.id.conform);
        zero = findViewById(R.id.zero);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        up = findViewById(R.id.up);
        down = findViewById(R.id.down);
        left = findViewById(R.id.left);
        right = findViewById(R.id.right);
        pick = findViewById(R.id.pick_controller);
        smart_learn = findViewById(R.id.mode_learn);
        vol_plus.setOnClickListener(this);
        vol_de.setOnClickListener(this);
        cancle.setOnClickListener(this);
        conform.setOnClickListener(this);
        up.setOnClickListener(this);
        down.setOnClickListener(this);
        left.setOnClickListener(this);
        right.setOnClickListener(this);
        zero.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        smart_learn.setOnClickListener(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.vol_de:
                Log.e("index",  "1"+SharedPreferenceManage.object.get(index).getString("volUp", "") + "1");

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("volUp", ""));

                break;
            case R.id.vol_plus:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("volDown", ""));


                break;
            case R.id.cancle:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("back", ""));

                break;
            case R.id.conform:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("ok", ""));

                break;
            case R.id.zero:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num0", ""));

                break;
            case R.id.one:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num1", ""));

                break;
            case R.id.two:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num2", ""));

                break;
            case R.id.three:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num3", ""));

                break;
            case R.id.four:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num4", ""));


                break;
            case R.id.five:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num5", ""));


                break;
            case R.id.six:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num6", ""));

                break;
            case R.id.seven:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num7", ""));

                break;
            case R.id.eight:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num8", ""));

                break;
            case R.id.nine:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("num9", ""));

                break;
            case R.id.up:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("up", ""));

                break;
            case R.id.down:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("down", ""));

                break;
            case R.id.left:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("left", ""));

                break;
            case R.id.right:

                Config.WriteData(Config.SEND_PATH, SharedPreferenceManage.object.get(index).getString("right", ""));

                break;
            case R.id.mode_learn:
                Intent intent = new Intent(ControllerActivity.this, LearnActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void initStore() {
        Log.e("KONKA","66666");
        LETV = SharedPreferenceManage.creatSharedpreference(this, "LETV");
        KONKA = SharedPreferenceManage.creatSharedpreference(this, "KONKA");
        SharedPreferences.Editor levteidt = LETV.edit();
        SharedPreferences.Editor knokaeidt = LETV.edit();
        Log.e("KONKA","66666");
        levteidt.putString("num0", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,20,21,62,21,20,21,20,21,62,21,20,21,62,21,62,21,62,21,20,21,62,21,1548,342,81,21,7826");
        levteidt.putString("num1", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,62,21,62,21,62,21,62,21,62,21,62,21,7826");
        levteidt.putString("num2", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,62,21,62,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("num3", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,62,21,62,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("num4", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("num5", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,62,21,62,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("num6", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,62,21,62,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("num7", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,62,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("num8", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,20,21,62,21,62,21,62,21,20,21,62,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("num9", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,20,21,62,21,20,21,20,21,20,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("up", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,62,21,20,21,62,21,20,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,62,21,62,21,62,21,62,21,7826");
        levteidt.putString("down", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,62,21,62,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,62,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("left", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,62,21,62,21,62,21,62,21,20,21,62,21,62,21,62,21,7826");
        levteidt.putString("right", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,20,21,62,21,62,21,62,21,20,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("volUp", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,62,21,62,21,1548,342,81,21,7826");
        levteidt.putString("volDown", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,62,21,62,21,62,21,20,21,20,21,20,21,62,21,62,21,20,21,20,21,20,21,62,21,62,21,62,21,7826");
        levteidt.putString("ok", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,62,21,62,21,20,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,62,21,62,21,62,21,62,21,1549,342,81,21,7826");
        levteidt.putString("back", "37313,342,167,21,20,21,20,21,62,21,62,21,20,21,20,21,62,21,20,21,62,21,20,21,62,21,20,21,20,21,62,21,62,21,20,21,62,21,20,21,62,21,62,21,62,21,20,21,20,21,20,21,20,21,62,21,20,21,20,21,20,21,62,21,62,21,62,21,7826");
        levteidt.putString("power", "");
        Log.e("KONKA","66666");
        knokaeidt.putString("volUp", "37313,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,93,19,148,19,865,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,93,19,148,19,865,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,93,19,148,19,7826");
        knokaeidt.putString("volDown", "37313,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,55,19,148,19,865,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,55,19,148,19,865,116,109,19,55,19,55,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,55,19,55,19,93,19,55,19,55,19,93,19,55,19,148,19,7826");
        knokaeidt.putString("ok", "");
        knokaeidt.putString("back", "");
        knokaeidt.putString("power", "");
        knokaeidt.putString("num0","");
        knokaeidt.putString("num1", "");
        knokaeidt.putString("num2", "");
        knokaeidt.putString("num3", "");
        knokaeidt.putString("num4", "");
        knokaeidt.putString("num5", "");
        knokaeidt.putString("num6", "");
        knokaeidt.putString("num7", "");
        knokaeidt.putString("num8", "");
        knokaeidt.putString("num9", "");
        knokaeidt.putString("up","");
        knokaeidt.putString("down","");
        knokaeidt.putString("left","");
        knokaeidt.putString("right","");
        knokaeidt.commit();
        Log.e("KONKA",KONKA.getString("volUp","sb"));
        levteidt.commit();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        switch (requestCode) {
            case 1:
                operationpick();
                break;

        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.item_spiner, SharedPreferenceManage.all);
        pick.setAdapter(arrayAdapter);
    }

}
