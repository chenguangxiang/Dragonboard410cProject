package com.etek.ircore;

import android.util.Log;

import com.ircode.IRCode;

/**
 * Created by root on 17-7-19.
 */

public class RemoteCore {
    private static final String libSoName = "IRCore";
	static {
        try {
            System.loadLibrary(libSoName);
            Log.e("JNI",libSoName+" load finished");
        }catch (Exception e){
            Log.e("JNI"," exception "+e.getMessage());
        }

	}





	public native static IRCode ET4007Learn(byte[] codes);

    public native static byte[] readLearnIRCode();

    public native static int IRinit();
}
