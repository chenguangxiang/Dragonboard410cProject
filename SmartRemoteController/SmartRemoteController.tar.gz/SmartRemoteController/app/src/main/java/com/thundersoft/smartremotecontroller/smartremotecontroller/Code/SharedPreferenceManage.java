package com.thundersoft.smartremotecontroller.smartremotecontroller.Code;


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by root on 17-7-20.
 */

public class SharedPreferenceManage {

    public static ArrayList<String> all = new ArrayList<>();
    public static ArrayList<SharedPreferences> object = new ArrayList<>();
    public static int MODE = MODE_PRIVATE;

    public static SharedPreferences creatSharedpreference(Context context, String name) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(name, MODE);
        all.add(name);
        object.add(sharedPreferences);
        Log.e("preference","");
        return sharedPreferences;
    }

    public static void nitifydata(SharedPreferences sharedPreferences, String key, String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(key);
        editor.putString(key, value);
        editor.commit();

    }

    public static void add(SharedPreferences sharedPreferences, String key, String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();


    }

/*    public static SharedPreferences getshapre(String name ){

        return object.get(object.indexOf(name));

    }*/

}
