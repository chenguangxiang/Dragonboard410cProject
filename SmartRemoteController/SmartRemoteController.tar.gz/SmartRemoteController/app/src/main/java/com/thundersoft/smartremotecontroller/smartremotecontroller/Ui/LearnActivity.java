package com.thundersoft.smartremotecontroller.smartremotecontroller.Ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.LoginFilter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.etek.ircore.RemoteCore;
import com.ircode.IRCode;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.Config;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.DialogUtil;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Code.SharedPreferenceManage;
import com.thundersoft.smartremotecontroller.smartremotecontroller.R;

import java.util.Timer;
import java.util.TimerTask;


public class LearnActivity extends Activity implements View.OnClickListener {

    private Button learn_mode, mode_send, cancle_learn, save_value;
    private TextView show_info;
    private ImageView im;
    private Timer timer;
    private String key;
    private IRCode irCode;
    private Message message;
    public static String irString;

    private Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            String key = "LearnData:    " + String.valueOf(msg.getData().get("key"));
            show_info.setText(key);
            save_value.setEnabled(true);
            mode_send.setEnabled(true);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn);

        initview();
        timer = new Timer();
    }



    private void initview() {
        learn_mode = findViewById(R.id.learn_mode);
        mode_send = findViewById(R.id.mode_send);
        cancle_learn = findViewById(R.id.cancle_learn);
        save_value = findViewById(R.id.save_value);
        show_info = findViewById(R.id.button_value);
        im = findViewById(R.id.start_learn);

        setEnabled(false);


        learn_mode.setOnClickListener(this);
        mode_send.setOnClickListener(this);
        cancle_learn.setOnClickListener(this);
        save_value.setOnClickListener(this);
        show_info.setOnClickListener(this);
    }

    private void setEnabled(boolean type) {
        mode_send.setEnabled(type);
        cancle_learn.setEnabled(type);
        save_value.setEnabled(type);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.learn_mode:
                im.setVisibility(View.VISIBLE);
                message = new Message();
                cancle_learn.setVisibility(View.VISIBLE);
                cancle_learn.setEnabled(true);
                Config.WriteData(Config.LEARN_PATH, "1");
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        String a = Config.Redata(Config.STATUS);
                        if (a.startsWith("0")) {
                           /* Config.Redata(Config.LEARN_PATH);*/
                            irCode = new ET4007IRDevice().readlearncode();
                            if (irCode.isValid()) {
                                irString = irCode.toString();
                            } else {
                                irString = "ERROR";
                            }
                            Bundle bundle = new Bundle();
                            bundle.putString("key", irString);
                            message.setData(bundle);
                            handler.sendMessage(message);
                            timer.cancel();

                        }

                    }
                }, 0, 1000);


                break;
            case R.id.mode_send:
                Config.WriteData(Config.SEND_PATH, irString);
                break;
            case R.id.cancle_learn:
                im.setVisibility(View.INVISIBLE);
                cancle_learn.setVisibility(View.INVISIBLE);
                setEnabled(false);
                timer.cancel();
                break;
            case R.id.save_value:
                 DialogUtil.launchdialog(this);
                break;

        }

    }


}
