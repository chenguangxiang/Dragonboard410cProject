package com.thundersoft.smartremotecontroller.smartremotecontroller.Code;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.thundersoft.smartremotecontroller.smartremotecontroller.R;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Ui.ControllerActivity;
import com.thundersoft.smartremotecontroller.smartremotecontroller.Ui.LearnActivity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

/**
 * Created by root on 17-7-18.
 */

public class DialogUtil {

    private static LayoutInflater inflater;
    private static String name=null ;
    private static String filename_index;
    private static String keyname_index;
    public static final String BYSELF="new by self";
    public  static   int status=0;
    public static int index;
    public static void launchdialog(final Context context){

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        inflater=LayoutInflater.from(context);
        View view =inflater.inflate(R.layout.dialog_view,null,false);
        builder.setView(view);
        final Dialog dialog =builder.create();
        dialog.show();

        final Spinner filename = view.findViewById(R.id.edit_file_name);
        ArrayList <String> filenamelist = SharedPreferenceManage.all;
        filenamelist.add(BYSELF);
        filename.setAdapter(new ArrayAdapter<>(context,R.layout.item_spiner, filenamelist));
        filename.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                  filename_index=filename.getSelectedItem().toString();
                  index=3;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final Spinner keyname = view.findViewById(R.id.edit_key_name);
        ArrayList<String> keynamelist=new ArrayList<String>(){{add("num0"); add("num1");
            add("num2");add("num3");add("num4");add("num5");add("num6");add("num7");add("num8");add("num9");add("up");
        add("down");add("left");add("right");add("volUp");add("volDown");add("ok");add("back");add("ppwer");}};
        keyname.setAdapter(new ArrayAdapter<>(context,R.layout.item_spiner,keynamelist));
        keyname.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 keyname_index=keyname.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        view.findViewById(R.id.cancle_name).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 dialog.cancel();
            }
        });
        final EditText editText=view.findViewById(R.id.newfile);
        view.findViewById(R.id.conform_name).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("edit","3 "+editText.getText().toString());
                name=editText.getText().toString();
                if (filename_index.contentEquals(BYSELF)){
                   SharedPreferences Byself=SharedPreferenceManage.creatSharedpreference(context,name);
                    SharedPreferenceManage.add(Byself,keyname_index,LearnActivity.irString);
                     dialog.cancel();
                }else {
                SharedPreferenceManage.nitifydata(SharedPreferenceManage.object.get(index),keyname_index,LearnActivity.irString);
                     dialog.cancel();

                }
            }
        });


    }

    public static void normaldiaolog(Context context){

        final AlertDialog.Builder builder= new AlertDialog.Builder(context);
        builder.setTitle("Warning");
        builder.setTitle("please select one brand!");
        builder.setNegativeButton("conform", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                builder.create().cancel();
            }
        });
        builder.create();
        builder.show();
    }

}
