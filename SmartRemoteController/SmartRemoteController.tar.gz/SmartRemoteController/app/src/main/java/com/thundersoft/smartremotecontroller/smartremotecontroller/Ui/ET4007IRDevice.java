package com.thundersoft.smartremotecontroller.smartremotecontroller.Ui;

import android.util.Log;

import com.etek.ircore.RemoteCore;

import com.ircode.IRCode;
/**
 * Created by root on 17-7-20.
 */

public class ET4007IRDevice {

      public ET4007IRDevice() {
		RemoteCore.IRinit();
		// TODO Auto-generated constructor stub
	}

	public   IRCode readlearncode(){
        IRCode code = null;
        byte [] tem;
        Log.e("BEFOR","fgdfg");
         tem= RemoteCore.readLearnIRCode();
        if (tem.length!=0){
            Log.e("BEFOR",tem+"111111");
             code= RemoteCore.ET4007Learn(tem);
            Log.e("ERROR",code+"");
        }
         return code;


    }
}
